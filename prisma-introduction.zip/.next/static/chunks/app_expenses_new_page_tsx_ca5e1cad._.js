(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_expenses_new_page_tsx_ca5e1cad._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_expenses_new_page_tsx_ca5e1cad._.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_f0619f27._.js",
    "static/chunks/node_modules_next_dist_9a2d5fdb._.js"
  ],
  "source": "dynamic"
});
