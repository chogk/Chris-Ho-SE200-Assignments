import { db } from "@/db";
import Link from 'next/link';


export default async function Page() {
  try {
    const expenseItems = await db.expenseItem.findMany();

    return (
      <div>
        <div className="flex justify-between items-center mb-4">
          <h1>Expense Items</h1>
          <Link href="/expenses/new" className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
            Add New Item
          </Link>
        </div>
        <br />

        {expenseItems.length === 0 ? (
          <div>No expense items found.</div>
        ) : (
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Item</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Description</th>
                <th scope="col" className="px-16 py-13 text-middle text-xs font-medium text-gray-500 uppercase tracking-wider">Edit</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {expenseItems.map((expenseItem, index) => (
                <tr key={expenseItem.id} className={index % 2 === 0 ? "bg-white" : "bg-gray-50"}>
                  <td className="px-6 py-4 whitespace-nowrap">{expenseItem.id}</td>
                  <td className="px-6 py-4 whitespace-nowrap">{expenseItem.item}</td>
                  <td className="px-6 py-4 whitespace-nowrap">{expenseItem.description}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium flex justify-end"></td>
                  <td className="px-6 py-4 whitespace-nowrap"><Link href={`/expenses/${expenseItem.id}/edit`} className="text-indigo-600 hover:text-indigo-900 mr-2 m-10">Update</Link></td>
                  <td className="px-6 py-4 whitespace-nowrap"><Link href={`/expenses/${expenseItem.id}/delete`} className="text-red-600 hover:text-red-900 m-10">Delete</Link></td>
                
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    );
  } catch (error) {
    console.error("Error fetching expense items:", error);
    return (
      <div>
        <h1>Expense Items</h1>
        <h2>Error loading expense items. Please try again.</h2>
      </div>
    );
  }
}