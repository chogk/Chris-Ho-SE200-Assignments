import { db } from '../../../db';
import { revalidatePath } from 'next/cache';
import { redirect } from 'next/navigation';
import Link from 'next/link';


// In a Server Component
export default function CreateExpenseForm() {

    async function createExpenseItem(formData: FormData) {
        'use server';
        const item = formData.get('item') as string;
        const description = formData.get('description') as string;
    
        try {
          await db.expenseItem.create({
            data: {
            item,
            description,
          }, 
        });
        
        console.log('Expense item created successfully.'); // Verify database operation
        redirect('/'); // Redirect after successful creation
        revalidatePath ('/');
                
      } catch (error) {
        console.error('Error creating expense item:', error);
        // Optionally, handle the error and display a message to the user
      }

    }
    
    return (
      <div className="flex justify-center items-center h-screen bg-gray-100">
        <form action={createExpenseItem}>
          <h1>Create an Expense Item</h1>
          <div>
            <label htmlFor="item">Item: </label>
            <input type="text" name="item" id="item" required />
          </div>
          <br />
          <div>
            <label htmlFor="description">Description: </label>
            <textarea name="description" id="description" required />
          </div>
          <br />
          <button type="submit"><h3 className="block text-gray-700 text-lg font-bold mb-6 text-center">Create Expense Item</h3></button>
          <br />
          <br />
          <br />
          <Link href="/" className="bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 px-4 rounded mb-4 inline-block">
            Return to Home
            </Link>
        </form>
      </div>
      
    );
  }