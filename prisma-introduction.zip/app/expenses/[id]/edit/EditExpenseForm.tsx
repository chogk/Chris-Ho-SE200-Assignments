// app/expenses/[id]/edit/EditExpenseForm.tsx
"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { updateExpenseItem } from "./expenseActions";
import Link from 'next/link';


interface EditExpenseFormProps {
  initialItem: string;
  initialDescription: string;
  id: number;
}

export default function EditExpenseForm({
  initialItem,
  initialDescription,
  id,
}: EditExpenseFormProps) {
  const [item, setItem] = useState(initialItem);
  const [description, setDescription] = useState(initialDescription);
  const router = useRouter();

  async function handleSubmit(formData: FormData) {
    await updateExpenseItem(id, formData);
  }

  return (
    <form action={handleSubmit} className="space-y-4">
      <div>
        <label htmlFor="item" className="block text-gray-700 text-sm font-bold mb-2">Item:</label>
        <input
          type="text"
          id="item"
          name="item"
          value={item}
          onChange={(e) => setItem(e.target.value)}
          required
          className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
        />
      </div>
      <br />
      <div>
        <label htmlFor="description" className="block text-gray-700 text-sm font-bold mb-2">Description:</label>
        <textarea
          id="description"
          name="description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          required
          className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
        />
      </div>
      <br />
      <button type="submit" className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">
        Update Expense Item
      </button>
      <br />
      <br />
      <br />
      <div><Link href="/"
        className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded mb-4 inline-block"
        >Return To Home </Link></div>
    </form>
  );
}