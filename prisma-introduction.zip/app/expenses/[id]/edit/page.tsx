// app/expenses/[id]/edit/page.tsx
import { db } from "@/db";
import EditExpenseForm from './EditExpenseForm';
import Link from 'next/link';

interface ExpenseEditPageProps {
  params: {
    id: string;
  };
}

export default async function ExpenseEditPage({ params }: ExpenseEditPageProps) {
  const id = parseInt(params.id);

  if (isNaN(id)) {
    return (
      <div className="flex justify-center items-center h-screen bg-gray-100">
        <div className="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4 w-full max-w-md">
          <h1>Invalid Expense ID.</h1>
          <p>Please provide a valid numeric ID.</p>
        </div>
      </div>
    );
  }

  try {
    const expenseItem = await db.expenseItem.findUnique({ // Use prisma here
      where: { id },
    });

    if (!expenseItem) {
      return (
        <div className="flex justify-center items-center h-screen bg-gray-100">
          <div className="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4 w-full max-w-md">
            <h1>Expense item not found.</h1>
            <p>The requested expense item does not exist.</p>
            <Link href="/" className="bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 px-4 rounded mb-4 inline-block">
            Return to Home
            </Link>
          </div>
        </div> 
            
      );
    }

    

    return (
      <div className="flex justify-center items-center h-screen bg-gray-100">
        <div className="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4 w-full max-w-md">
          <h1 className="block text-gray-700 text-lg font-bold mb-6 text-center">
            Edit Expense Item
          </h1>
       
          <EditExpenseForm
            initialItem={expenseItem.item} // Assuming 'item' was a mistake, and you need 'description'
            initialDescription={expenseItem.description}
            id={expenseItem.id}
          />
        </div>
      </div>
    );
  } catch (error) {
    console.error('Error fetching expense item:', error);
    return (
      <div className="flex justify-center items-center h-screen bg-gray-100">
        <div className="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4 w-full max-w-md">
          <h1>Error loading expense item.</h1>
          <p>Please try again later.</p>
          <p><Link href="/"
        className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded mb-4 inline-block"
        > Return To Home </Link></p>
        </div>
      </div>
    );
  }
}