// app/expenses/[id]/edit/expenseActions.ts
"use server";

import { db } from "@/db";
import { redirect } from "next/navigation";

export async function updateExpenseItem(id: number, formData: FormData) {
  if (!id || isNaN(id)) {
    throw new Error("Invalid expense ID.");
  }

  const newItem = formData.get("item") as string;
  const newDescription = formData.get("description") as string;

  try {
    const updatedItem = await db.expenseItem.update({
      where: { id },
      data: {
        item: newItem,
        description: newDescription,
      },
    });


     
    
  } catch (error) {
    console.error("Error updating expense item:", error);
    // Handle the error (e.g., display an error message)
  }
}