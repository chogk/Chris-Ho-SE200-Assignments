import Link from 'next/link'; 
import { db } from '@/db';

type ExpenseShowPageProps = {
  params: {
    id: string;
  };
}

export default async function ExpensesShowPage(props: ExpenseShowPageProps) {
  const expenseItem = await db.expenseItem.findFirst({
    where: { id: parseInt(props.params.id) },
  });

  if (!expenseItem) {
     return <div>Expense Item Not Found</div>;
  }

  return <>
   <table>
        <tbody className="bg-red divide-y divide-gray-200">
            <tr>
                <td className="px-16 py-14 bg-gray-500">{expenseItem.id}</td>
                <td className="px-16 py-14 bg-gray-50">{expenseItem.item}</td>
                <td className="px-16 py-14 bg-gray-50">{expenseItem.description}</td>
            </tr>
        </tbody>
  </table>
  <Link
        href="/"
        className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded mb-4 inline-block"
        >
        Home
  </Link>
  </>;
}
