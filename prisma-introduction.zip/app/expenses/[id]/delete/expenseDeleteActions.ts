"use server";

import { db } from "@/db";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";

export async function handleDelete(id: number, confirm: boolean) {
  if (confirm) {
    try {
      await db.expenseItem.delete({
        where: { id },
      });
      revalidatePath("/");
      //redirect("/");
      return { success: true }; // Return success
    }  
    catch (error) {
      console.error("Error deleting expense item:", error);
      // Handle error (e.g., display an error message)
      return { success: false, error: "Error deleting item." }; // Return error
    }
  } else {
    revalidatePath("/");
    redirect("/");
    return { success: true }; // Return success (no deletion)
  }
}