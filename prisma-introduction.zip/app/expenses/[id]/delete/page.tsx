"use client";

import { useRouter } from "next/navigation";
import { handleDelete } from "./expenseDeleteActions"; 
import React from 'react'; // Import React
import Link from 'next/link';

interface ExpenseDeletePageProps {
  params: {
    id: string;
  };
}

export default function ExpenseDeletePage({ params }: ExpenseDeletePageProps) {
    const router = useRouter();
    const unwrappedParams = React.use(params); // Unwrap params
    const id = parseInt(unwrappedParams.id); // Access params.id
  
    async function handleYes() {
      await handleDelete(id, true);
    }
  
    async function handleNo() {
      await handleDelete(id, false);
    }
  
    return (
      <div>
        <Link href="/"
        className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded mb-4 inline-block"
        > Home </Link>
        <br />
        <h1>Confirm Delete</h1>
        <p>Are you sure you want to delete this expense item?</p>
        <table>
        <tbody className="bg-white divide-y divide-gray-200">
            <tr>
                <td className="px-6 py-4 whitespace-nowrap"><button onClick={handleYes}>Yes</button></td>
                <td className="px-6 py-4 whitespace-nowrap"><button onClick={handleNo}>No</button></td>
            </tr>
        </tbody>
      </table>
        
      </div>
    );
  }
