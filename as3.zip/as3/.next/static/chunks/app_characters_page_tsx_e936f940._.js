(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_characters_page_tsx_e936f940._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_characters_page_tsx_e936f940._.js",
  "chunks": [],
  "source": "dynamic"
});
