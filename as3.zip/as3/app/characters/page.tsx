// ✅ Characters Main Page
import Link from "next/link";

async function getCharacters() {
  const res = await fetch("https://www.anapioficeandfire.com/api/characters?page=1&pageSize=10");
  return res.json();
}

export default async function CharactersPage() {
  const characters = await getCharacters();

  return (
    <div>
      <h1 className="text-3xl font-bold mb-4">Characters</h1>
      <ul className="space-y-4">
        {characters.map((character: any, index: number) => (
          <li key={index} className="border-b border-gray-700 pb-2">
            <Link href={`/characters/${character.url.split("/").pop()}`} className="text-lg text-blue-400 hover:underline">
              {character.name && character.name.trim() !== "" ? character.name : `${character.aliases[0]} (Alias)`}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
