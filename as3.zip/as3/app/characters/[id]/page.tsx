{/* To output the content downloaded from  */}

import { notFound } from "next/navigation";

// ✅ Fetch Character Data Function
async function fetchCharacter(id: string) {
    try {
        const res = await fetch(`https://www.anapioficeandfire.com/api/characters/${id}`, {
            next: { revalidate: 86400 }, // Revalidate every 24 hours
        });

        if (!res.ok) {
            return null;
        }

        return await res.json();
    } catch (error) {
        console.error("Error fetching character:", error);
        return null;
    }
}

// ✅ Generate Static Paths for Pre-rendering
export async function generateStaticParams() {
    try {
        const res = await fetch("https://www.anapioficeandfire.com/api/characters?page=1&pageSize=10");

        if (!res.ok) {
            return [];
        }

        const characters = await res.json();

        return characters.map((character: { url: string }) => ({
            id: character.url.split("/").pop(),
        }));
    } catch (error) {
        console.error("Error in generateStaticParams:", error);
        return [];
    }
}

// ✅ Character Detail Page
export default async function CharacterDetail({ params }: { params: { id: string } }) {
    const { id } = await params;  // Ensure params is awaited before usage
    const character = await fetchCharacter(id);

    if (!character) return notFound();

    return (
        <div className="min-h-screen bg-gray-900 text-white p-6">
            {/* Character Name */}
            <h1 className="text-3xl font-bold mb-4">
                {character.name || (character.aliases?.[0] ? `${character.aliases[0]} (Alias)` : "Unknown Character")}
            </h1>
            <p className="text-lg mb-2">Name: {character.name || "Unknown"}</p>
            <p className="text-lg mb-2">Gender: {character.gender || "Unknown"}</p>
            <p className="text-lg mb-2">Culture: {character.culture || "Unknown"}</p>
            <p className="text-lg mb-2">Born: {character.born || "Unknown"}</p>
            <p className="text-lg mb-2">Died: {character.died || "Unknown"}</p>

            {/* Titles Section */}
            <h2 className="text-2xl font-bold mb-4">Titles</h2>
            <ul className="list-disc pl-5 mb-2">
                {character.titles?.length > 0 ? character.titles.map((title: string, index: number) => (
                    <li key={index}>{title}</li>
                )) : <li>None</li>}
            </ul>

            {/* Aliases Section */}
            <h2 className="text-2xl font-bold mb-4">Aliases</h2>
            <ul className="list-disc pl-5 mb-2">
                {character.aliases?.length > 0 ? character.aliases.map((alias: string, index: number) => (
                    <li key={index}>{alias}</li>
                )) : <li>None</li>}
            </ul>
        </div>
    );
}
