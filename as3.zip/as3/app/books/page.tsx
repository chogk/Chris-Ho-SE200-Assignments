
// Books Main Page
import Link from "next/link";

async function getBooks() {
  const res = await fetch("https://www.anapioficeandfire.com/api/books");
  return res.json();
}

export default async function BooksPage() {
  const books = await getBooks();

  return (
    <div>
      <h1 className="text-3xl font-bold mb-4">Books</h1>
      <ul className="space-y-4">
        {books.map((book: any, index: number) => (
          <li key={index} className="border-b border-gray-700 pb-2">
            <Link href={`/books/${book.url.split("/").pop()}`} className="text-lg text-blue-400 hover:underline">
              {book.name}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}