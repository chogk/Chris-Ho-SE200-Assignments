import { notFound } from "next/navigation";
import Link from "next/link";

// Function to generate static params for books
export async function generateStaticParams() {
  try {
    const res = await fetch("https://www.anapioficeandfire.com/api/books", {
      next: { revalidate: 86400 }, // Cache for 24 hours
    });

    if (!res.ok) throw new Error("Failed to fetch books");

    const books = await res.json();
    return books.map((book: any) => ({ id: book.url.split("/").pop() }));
  } catch (error) {
    console.error("Error fetching books:", error);
    return [];
  }
}

// Function to fetch a book by ID
async function fetchBook(id: string) {
  const res = await fetch(`https://www.anapioficeandfire.com/api/books/${id}`);
  if (!res.ok) return null;
  return res.json();
}

// Function to fetch character details
async function fetchCharacter(url: string) {
  const res = await fetch(url);
  if (!res.ok) return null;
  return res.json();
}

// Book Detail Page
export default async function BookDetail({ params }: { params: { id: string } }) {
    const { id } = await params;  // Ensure params is awaited before usage

    const book = await fetchBook(id);  
    if (!book) return notFound();  

  const formattedDate = book.released ? new Date(book.released).toLocaleDateString("en-US") : "Unknown";
  const authors = book.authors?.length ? book.authors.join(", ") : "Unknown";

  // Fetch POV characters concurrently
  const povCharacterResults = await Promise.allSettled(
    book.povCharacters.map(fetchCharacter)
  );

  // Filter out failed requests
  const povCharacters = povCharacterResults
    .filter((result) => result.status === "fulfilled" && result.value)
    .map((result) => {
      const charData = (result as PromiseFulfilledResult<any>).value;
      const charId = charData.url.split("/").pop();
      return { id: charId, name: charData.name || `Character ${charId}` };
    });

  return (
    <div className="min-h-screen bg-gray-900 text-white p-6">
      <h1 className="text-3xl font-bold mb-4">{book.name}</h1>
      <p className="text-lg mb-2">ISBN: {book.isbn || "N/A"}</p>
      <p className="text-lg mb-2">Authors: {authors}</p>
      <p className="text-lg mb-2">Number of Pages: {book.numberOfPages || "Unknown"}</p>
      <p className="text-lg mb-2">Publisher: {book.publisher || "Unknown"}</p>
      <p className="text-lg mb-2">Country: {book.country || "Unknown"}</p>
      <p className="text-lg mb-2">Released: {formattedDate}</p>

      <h2 className="text-2xl mt-4">POV Characters</h2>
      <ul className="list-disc pl-5 mb-2">
        {povCharacters.length > 0 ? (
          povCharacters.map((char) => (
            <li key={char.id}>
              <Link href={`/characters/${char.id}`} className="text-blue-400 hover:underline">
                Character {char.id}
              </Link>
            </li>
          ))
        ) : (
          <li>None</li>
        )}
      </ul>
    </div>
  );
}