// ✅ World of Ice and Fire Main Page
import React from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";

export default function Home() {
  return (
    <div className="min-h-screen bg-gray-900 text-white flex flex-col items-center justify-center p-4">
      <h1 className="text-4xl font-bold mb-4">Welcome to the World of Ice and Fire</h1>
      <p className="text-lg mb-6 max-w-2xl text-center">
      Explore the rich universe of Game of Thrones and A Song of Ice and Fire.
      </p>
      <div className="flex space-x-4">
        <ul className="list-inside">
          <Link href="/characters"><li>Characters</li></Link>
          <Link href="/books"><li>Books</li></Link>
          
        </ul>  
      </div>
    </div>
  );
}

